const express = require('express');
const multer = require('../middleware/multer');
const Aluno = require('../models/Aluno');

app.post('/enviar-arquivo', upload.single('arquivoEnviado'), (req, res) => {
    if (!req.file) {
        return res.status(400).send('Nenhum arquivo foi enviado.');
    }

    const nomeOriginal = req.file.originalname;
    const nomeServidor = req.file.filename;
    const caminhoArquivo = req.file.path;
    
    // TODO: pegar ID do aluno logado via sessão/autenticação
    const alunoId = 1; 

    const sql = 'INSERT INTO entregas (nome_original, nome_servidor, caminho_arquivo, idAluno) VALUES (?, ?, ?, ?)';
    
    banco.query(sql, [nomeOriginal, nomeServidor, caminhoArquivo, alunoId], (erro, resultados) => {
        if (erro) {
            console.error('Erro ao salvar no banco:', erro);
            return res.status(500).send('Erro ao salvar as informações do arquivo.');
        }
        console.log('Arquivo salvo no banco de dados!');
        res.send('Arquivo enviado com sucesso!');
    });
});