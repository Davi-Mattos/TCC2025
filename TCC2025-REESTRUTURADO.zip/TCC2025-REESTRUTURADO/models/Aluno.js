const Banco = require('../config/db');
const bcrypt = require('bcrypt');

class Aluno {
    constructor() {
        this._emailAluno = null;
        this._senhaAluno = null;
        this._nomeAluno = null;
        this._turma = null;
        this._idCurso = null;
    }

  
    async create() {
        const conexao = Banco.getConexao();
        const saltRounds = 10;

        try {
            const senhaHash = await bcrypt.hash(this._senhaAluno, saltRounds);
            const SQL = `
                INSERT INTO aluno 
                (nomeAluno, emailAluno, senhaAluno, turma, idCurso) 
                VALUES (?, ?, ?, ?, ?);
            `;

            const [result] = await conexao.promise().execute(SQL, [
                this._nomeAluno, 
                this._emailAluno, 
                senhaHash,
                this._turma,
                this._idCurso
            ]);

            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro no modelo ao criar aluno:', error);
            return false;
        }
    }


    async update() {
        const conexao = Banco.getConexao();
        const saltRounds = 10;

        try {
            const senhaHash = await bcrypt.hash(this._senhaAluno, saltRounds);
            const SQL = 'UPDATE aluno SET senhaAluno = ? WHERE emailAluno = ?;';
            const [result] = await conexao.promise().execute(SQL, [senhaHash, this._emailAluno]);

            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro ao atualizar o Aluno:', error);
            return false;
        }
    }


    async login() {
        const conexao = Banco.getConexao();
        const SQL = `
            SELECT senhaAluno, emailAluno
            FROM aluno 
            WHERE emailAluno = ?;
        `;

        try {
            const [rows] = await conexao.promise().execute(SQL, [this._emailAluno]);

            if (rows.length === 1) {
                const hashArmazenado = rows[0].senhaAluno;
                const senhaCorreta = await bcrypt.compare(this._senhaAluno, hashArmazenado);

                if (senhaCorreta) {
                    this._emailAluno = rows[0].emailAluno;
                    return true;
                }
            }

            return false;
        } catch (error) {
            console.error('Erro ao realizar o login:', error);
            return false;
        }
    }


    async delete() {
        const conexao = Banco.getConexao();
        const SQL = 'DELETE FROM aluno WHERE emailAluno = ?;';
        try {
            const [result] = await conexao.promise().execute(SQL, [this._emailAluno]);
            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro ao excluir o Aluno:', error);
            return false;
        }
    }


    async readAll() {
        const conexao = Banco.getConexao();
        const SQL = 'SELECT * FROM aluno ORDER BY emailAluno;';
        try {
            const [rows] = await conexao.promise().execute(SQL);
            return rows;
        } catch (error) {
            console.error('Erro ao ler Alunos:', error);
            return [];
        }
    }

    async readByEmail() {
        const conexao = Banco.getConexao();
        const SQL = 'SELECT * FROM aluno WHERE emailAluno = ?;';
        try {
            const [rows] = await conexao.promise().execute(SQL, [this._emailAluno]);
            return rows;
        } catch (error) {
            console.error('Erro ao ler Aluno pelo email:', error);
            return null;
        }
    }

    async isUsuarioByEmail(email) {
        const conexao = Banco.getConexao();
        const SQL = 'SELECT COUNT(*) AS qtd FROM aluno WHERE emailAluno = ?;';
        try {
            const [rows] = await conexao.promise().execute(SQL, [email]);
            return rows[0].qtd > 0;
        } catch (error) {
            console.error('Erro ao verificar o email:', error);
            return false;
        }
    }


    get emailAluno() { return this._emailAluno; }
    set emailAluno(email) { this._emailAluno = email; }

    get senhaAluno() { return this._senhaAluno; }
    set senhaAluno(senha) { this._senhaAluno = senha; }

    get nomeAluno() { return this._nomeAluno; }
    set nomeAluno(nome) { this._nomeAluno = nome; }

    get turma() { return this._turma; }
    set turma(turma) { this._turma = turma; }

    get idCurso() { return this._idCurso; }
    set idCurso(idCurso) { this._idCurso = idCurso; }
}

module.exports = Aluno;
