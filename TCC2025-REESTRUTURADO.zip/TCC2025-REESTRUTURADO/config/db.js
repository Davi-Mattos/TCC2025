const mysql = require('mysql');

const pool = mysql.createPool({
    connectionLimit: 128,
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'tcc2025'
});
module.exports = pool;
