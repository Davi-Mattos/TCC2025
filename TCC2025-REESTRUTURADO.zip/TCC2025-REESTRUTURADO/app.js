const express = require('express');
const path = require('path');
const app = express();
const banco = require('./config/db.js');
const upload = require('./middleware/multer.js');


const AlunoRouter = require('./routes/AlunoRouter.js');
const ProfessorRouter = require('./routes/ProfessorRouter.js');
const LoginRouter = require('./routes/LoginRouter.js');
const GrupoRouter = require('./routes/GrupoRouter.js');
const EntregaRouter = require('./routes/EntregaRouter.js');

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Rotas separadas
app.use('/api/alunos', new AlunoRouter(banco));
app.use('/api/professores', new ProfessorRouter(banco));
app.use('/api/login', new LoginRouter(banco));
app.use('/api/grupos', new GrupoRouter(banco));
app.use('/api/entregas', new EntregaRouter(banco, upload));

// Rotas de páginas HTML
app.use('/', require('./routes/PaginasRouter.js'));

const porta = 3000;
app.listen(porta, () => {
    console.log(`Servidor rodando: http://localhost:${porta}`);
});
