const express = require('express');
const path = require('path');
const router = express.Router();

router.get('/login', (req, res) => res.sendFile(path.join(__dirname, '../../view/login.html')));
router.get('/alunos', (req, res) => res.sendFile(path.join(__dirname, '../../view/alunos.html')));
router.get('/professores', (req, res) => res.sendFile(path.join(__dirname, '../../view/professores.html')));
router.get('/entrega', (req, res) => res.sendFile(path.join(__dirname, '../../view/entrega.html')));
router.get('/cadastrargrupo', (req, res) => res.sendFile(path.join(__dirname, '../../view/cadastrargrupo.html')));
router.get('/', (req, res) => res.sendFile(path.join(__dirname, '../../view/inicial.html')));

module.exports = router;
