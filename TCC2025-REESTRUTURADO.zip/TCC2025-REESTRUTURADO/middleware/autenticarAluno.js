

function autenticarAluno(req, res, next) {
    if (req.session && req.session.alunoLogado) {
        next();
    } else {
        res.status(401).json({ erro: 'Você precisa estar logado.' });
    }
}

module.exports = autenticarAluno;
