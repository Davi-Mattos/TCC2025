
const Banco = require('./Banco');


module.exports = class Curso {
    
    constructor() {
        this._idCurso = null;
        this._nomeCurso = null; 
    }
    
    async create() {
        const conexao = Banco.getConexao();
        const SQL = 'INSERT INTO curso (nomeCurso) VALUES (?));';

        try {
            const [result] = await conexao.promise().execute(SQL, [
                this._nomeCurso
            ]);
            this._idCurso= result.insertId; 
            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro ao criar o Curso:', error);
            return false;
        }
    }

   
    async delete() {
        const conexao = Banco.getConexao();
        const SQL = 'DELETE FROM curso WHERE nomeCurso = ?;';
    
        try {
            const [result] = await conexao.promise().execute(SQL, [this._nomeCurso]);
            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro ao excluir o Curso:', error);
            return false;
        }
    }

   
    async update() {
        const conexao = Banco.getConexao();
        const SQL = 'UPDATE curso SET nomeCurso = MD5(?) WHERE idCurso = ?;';
    
        try {
            const [result] = await conexao.promise().execute(SQL, [this._nomeCurso, this._idCurso]);
            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro ao atualizar o Curso:', error);
            return false;
        }
    }

    
    async readAll() {
        const conexao = Banco.getConexao();
        const SQL = 'SELECT * FROM curso ORDER BY nomeCurso;';
    
        try {
            const [rows] = await conexao.promise().execute(SQL);
            return rows;
        } catch (error) {
            console.error('Erro ao ler Cursos:', error);
            return [];
        }
    }
    
 
    async readByID() {
        const conexao = Banco.getConexao();
        const SQL = 'SELECT * FROM curso WHERE idCurso = ?;';
    
        try {
            const [rows] = await conexao.promise().execute(SQL, [this._idCurso]);
            return rows;
        } catch (error) {
            console.error('Erro ao ler Curso pelo ID:', error);
            return null;
        }
    }
    
    
    
    set idCurso(novoIdCurso) {
        this._idCurso = novoidCurso;
    }
    get idCurso() {
        return this._idCurso;
    }

    set nomeCurso(novoNomeCurso) {
        this._nomeCurso = novoNomeCurso;
    }
    get nomeCurso() {
        return this._nomeCurso;
    }
};

module.exports = Curso;
