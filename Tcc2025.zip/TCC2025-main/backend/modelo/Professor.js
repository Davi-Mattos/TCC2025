
const Banco = require('./Banco');


module.exports = class Professor {
    
    constructor() {
        this._idProfessor = null;
        this._nomeProfessor = null; 
        this._emailProfessor = null; 
        this._senha = null; 
    }
    
    async create() {
        const conexao = Banco.getConexao();
        const SQL = 'INSERT INTO professor (nomeProfessor, emailProfessor, senha) VALUES (?, ?, MD5(?));';

        try {
            const [result] = await conexao.promise().execute(SQL, [
                this._nomeProfessor,
                this._emailProfessor,
                this._senha
            ]);
            this._idProfessor = result.insertId; 
            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro ao criar o Professor:', error);
            return false;
        }
    }

   
    async delete() {
        const conexao = Banco.getConexao();
        const SQL = 'DELETE FROM professor WHERE emailProfessor = ?;';
    
        try {
            const [result] = await conexao.promise().execute(SQL, [this._emailProfessor]);
            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro ao excluir o Professor:', error);
            return false;
        }
    }

   
    async update() {
        const conexao = Banco.getConexao();
        const SQL = 'UPDATE professor SET senha = MD5(?) WHERE emailProfessor = ?;';
    
        try {
            const [result] = await conexao.promise().execute(SQL, [this._senha, this._emailProfessor]);
            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro ao atualizar o Professor:', error);
            return false;
        }
    }

    
    async readAll() {
        const conexao = Banco.getConexao();
        const SQL = 'SELECT * FROM professor ORDER BY emailProfessor;';
    
        try {
            const [rows] = await conexao.promise().execute(SQL);
            return rows;
        } catch (error) {
            console.error('Erro ao ler Professores:', error);
            return [];
        }
    }
    
 
    async readByID() {
        const conexao = Banco.getConexao();
        const SQL = 'SELECT * FROM professor WHERE emailProfessor = ?;';
    
        try {
            const [rows] = await conexao.promise().execute(SQL, [this._emailProfessor]);
            return rows;
        } catch (error) {
            console.error('Erro ao ler Professor pelo email:', error);
            return null;
        }
    }

    async isProfessorByEmail(emailProfessor) {
        const conexao = Banco.getConexao();
        const SQL = 'SELECT COUNT(*) AS qtd FROM professor WHERE emailProfessor = ?;';  
    
        try {
            const [rows] = await conexao.promise().execute(SQL, [emailProfessor]); 
            return rows[0].qtd > 0;  
        } catch (error) {
            console.error('Erro ao verificar o email do Professor:', error);
            return false;  
        }
    }

    
    async login() {
        const conexao = Banco.getConexao();  
        const SQL = `
            SELECT COUNT(*) AS qtd, emailProfessor
            FROM professor
            WHERE emailProfessor = ? AND senha = MD5(?);
        `;  
    
        try {
           
            const [rows] = await conexao.promise().execute(SQL, [this._emailProfessor, this._senha]);
    
            if (rows.length > 0 && rows[0].qtd === 1) {
                const tupla = rows[0];
                this._emailProfessor = tupla.emailProfessor;
    
                return true;  
            }
    
            return false; 
        } catch (error) {
            console.error('Erro ao realizar o login do Professor:', error);  
            return false;  
        }
    }
    
    
    set idProfessor(novoIdProfessor) {
        this._idProfessor = novoIdProfessor;
    }
    get idProfessor() {
        return this._idProfessor;
    }

    set nomeProfessor(novoNomeProfessor) {
        this._nomeProfessor = novoNomeProfessor;
    }
    get nomeProfessor() {
        return this._nomeProfessor;
    }

    set emailProfessor(novoEmailProfessor) {
        this._emailProfessor = novoEmailProfessor;
    }
    get emailProfessor() {
        return this._emailProfessor;
    }

    set senha(novaSenha) {
        this._senha = novaSenha;
    }
    get senha() {
        return this._senha;
    }
};

module.exports = Professor;
