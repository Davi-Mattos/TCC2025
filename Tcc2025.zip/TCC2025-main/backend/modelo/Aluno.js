
const Banco = require('./Banco');


module.exports = class Aluno {
    
    constructor() {
        this._idAluno = null;
        this._nomeAluno = null; 
        this._turma = null; 
        this._emailAluno = null;
        this._senhaAluno = null; 
    }
    setidCurso(idCurso){
        this.idCurso = null;
    }
    getidCurso(idCurso){
        return this._idCurso;
    }
    
    async create() {
        const conexao = Banco.getConexao();
        const SQL = 'INSERT INTO aluno (nomeAluno, emailAluno, senhaAluno) VALUES (?, ?, MD5(?));';

        try {
            const [result] = await conexao.promise().execute(SQL, [
                this._nomeAluno,
                this._emailAluno,
                this._senhaAluno
            ]);
            this._idAluno = result.insertId; 
            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro ao criar o Aluno:', error);
            return false;
        }
    }

   
    async delete() {
        const conexao = Banco.getConexao();
        const SQL = 'DELETE FROM aluno WHERE emailAluno = ?;';
    
        try {
            const [result] = await conexao.promise().execute(SQL, [this._emailAluno]);
            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro ao excluir o Aluno:', error);
            return false;
        }
    }

   
    async update() {
        const conexao = Banco.getConexao();
        const SQL = 'UPDATE aluno SET senha = MD5(?) WHERE emailAluno = ?;';
    
        try {
            const [result] = await conexao.promise().execute(SQL, [this._senhaAluno, this._emailAluno]);
            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro ao atualizar o Aluno:', error);
            return false;
        }
    }

    
    async readAll() {
        const conexao = Banco.getConexao();
        const SQL = 'SELECT * FROM aluno ORDER BY emailAluno;';
    
        try {
            const [rows] = await conexao.promise().execute(SQL);
            return rows;
        } catch (error) {
            console.error('Erro ao ler Alunos:', error);
            return [];
        }
    }
    
 
    async readByID() {
        const conexao = Banco.getConexao();
        const SQL = 'SELECT * FROM aluno WHERE idAluno = ?;';
    
        try {
            const [rows] = await conexao.promise().execute(SQL, [this._emailAluno]);
            return rows;
        } catch (error) {
            console.error('Erro ao ler Aluno pelo email:', error);
            return null;
        }
    }

    async isAlunoByEmail(emailAluno) {
        const conexao = Banco.getConexao();
        const SQL = 'SELECT COUNT(*) AS qtd FROM aluno WHERE emailAluno = ?;';  
    
        try {
            const [rows] = await conexao.promise().execute(SQL, [emailAluno]); 
            return rows[0].qtd > 0;  
        } catch (error) {
            console.error('Erro ao verificar o email do Aluno:', error);
            return false;  
        }
    }

    
    async login() {
        const conexao = Banco.getConexao();  
        const SQL = `
            SELECT COUNT(*) AS qtd, emailAluno
            FROM aluno
            WHERE emailAluno = ? AND senha = MD5(?);
        `;  
    
        try {
           
            const [rows] = await conexao.promise().execute(SQL, [this._emailAluno, this._senha]);
    
            if (rows.length > 0 && rows[0].qtd === 1) {
                const tupla = rows[0];
                this._emailAluno = tupla.emailAluno;
    
                return true;  
            }
    
            return false; 
        } catch (error) {
            console.error('Erro ao realizar o login do Aluno:', error);  
            return false;  
        }
    }
    
    
    set idAluno(novoIdAluno) {
        this._idPAluno = novoIdAluno;
    }
    get idAluno() {
        return this._idAluno;
    }

    set nomeAluno(novoNomeAluno) {
        this._nomeAluno = novoNomeAluno;
    }
    get nomeAluno() {
        return this._nomeAluno;
    }

    set emailAluno(novoEmailAluno) {
        this._emailAluno = novoEmailAluno;
    }
    get emailAluno() {
        return this._emailAluno;
    }

    set senha(novaSenha) {
        this._senha = novaSenha;
    }
    get senha() {
        return this._senha;
    }
};

module.exports = Aluno;
