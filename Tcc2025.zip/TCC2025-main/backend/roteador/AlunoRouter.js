const express = require('express');
const AlunoControl = require('../controle/AlunoControl');
const AlunoMiddleware = require('../middleware/AlunoMiddleware');
const JwtMiddleware = require('../middleware/JWTMiddleware');

module.exports = class AlunoRouter {
    constructor() {
        this._router = express.Router();
        this._alunoControl = new AlunoControl();
        this._alunoMiddleware = new AlunoMiddleware();
        this._jwtMiddleware = new JwtMiddleware();
    }

    createRoutes() {
        
        this.router.get('/',
            this.jwtMiddleware.validate,
            this.alunoControl.readAll
        );

        
        this.router.get('/:email',
            this.jwtMiddleware.validate,
            this.alunoControl.readById
        );

        // Criar novo aluno
        this.router.post('/',
            this.jwtMiddleware.validate,
            this.alunoMiddleware.validate_emailAluno,
            this.alunoMiddleware.validate_senhaAluno,
            this.alunoMiddleware.isNotEmailCadastrado,
            this.alunoControl.create
        );

        // Atualizar aluno
        this.router.put('/:email',
            this.jwtMiddleware.validate,
            this.alunoMiddleware.validate_emailAluno,
            this.alunoMiddleware.validate_senhaAluno,
            this.alunoControl.update
        );

        // Excluir aluno
        this.router.delete('/:email',
            this.jwtMiddleware.validate,
            this.alunoControl.delete
        );

        return this._router;
    }

    get router() {
        return this._router;
    }

    set router(newRouter) {
        this._router = newRouter;
    }

    get alunoControl() {
        return this._alunoControl;
    }

    set alunoControl(newAlunoControl) {
        this._alunoControl = newAlunoControl;
    }

    get alunoMiddleware() {
        return this._alunoMiddleware;
    }

    set alunoMiddleware(newAlunoMiddleware) {
        this._alunoMiddleware = newAlunoMiddleware;
    }

    get jwtMiddleware() {
        return this._jwtMiddleware;
    }

    set jwtMiddleware(newJwtMiddleware) {
        this._jwtMiddleware = newJwtMiddleware;
    }
}
