const express = require('express');
const autenticarProfessor = require('../middleware/autenticarProfessor');
const Professor = require('../models/Professor');

const router = express.Router();


router.use(autenticarProfessor);

router.get('/', async (req, res) => {
    try {
        const professor = new Professor();
        const lista = await professor.readAll();
        res.json(lista);
    } catch (erro) {
        console.error('Erro ao listar professores:', erro);
        res.status(500).json({ erro: 'Erro ao listar professores' });
    }
});

router.post('/', async (req, res) => {
    const { nomeProfessor, emailProfessor, senhaProfessor } = req.body;

    if (!nomeProfessor || !emailProfessor || !senhaProfessor) {
        return res.status(400).json({ erro: 'Campos obrigatórios não preenchidos' });
    }

    const professor = new Professor();
    professor.nomeProfessor = nomeProfessor;
    professor.emailProfessor = emailProfessor;
    professor.senhaProfessor = senhaProfessor;

    try {
        const criado = await professor.create();
        if (criado) {
            return res.status(201).json({ mensagem: 'Professor criado com sucesso!' });
        } else {
            return res.status(500).json({ erro: 'Erro ao criar professor' });
        }
    } catch (erro) {
        console.error('Erro ao criar professor:', erro);
        res.status(500).json({ erro: 'Erro ao criar professor' });
    }
});

router.post('/login', async (req, res) => {
    const { emailProfessor, senhaProfessor } = req.body;

    if (!emailProfessor || !senhaProfessor) {
        return res.status(400).json({ erro: 'Email e senha são obrigatórios' });
    }

    const professor = new Professor();
    professor.emailProfessor = emailProfessor;
    professor.senhaProfessor = senhaProfessor;

    try {
        const sucesso = await professor.login();
        if (sucesso) {
            req.session.professorLogado = {
                email: professor.emailProfessor,
                nome: professor.nomeProfessor
            };

            return res.status(200).json({ mensagem: 'Login realizado com sucesso' });
        } else {
            return res.status(401).json({ erro: 'Credenciais inválidas' });
        }
    } catch (erro) {
        console.error('Erro ao fazer login:', erro);
        res.status(500).json({ erro: 'Erro interno ao realizar login' });
    }
});

router.delete('/:emailProfessor', async (req, res) => {
    const { emailProfessor } = req.params;

    const professor = new Professor();
    professor.emailProfessor = emailProfessor;

    try {
        const excluido = await professor.delete();
        if (excluido) {
            return res.json({ mensagem: 'Professor excluído com sucesso' });
        } else {
            return res.status(404).json({ erro: 'Professor não encontrado' });
        }
    } catch (erro) {
        console.error('Erro ao excluir professor:', erro);
        res.status(500).json({ erro: 'Erro ao excluir professor' });
    }
});

module.exports = router;
