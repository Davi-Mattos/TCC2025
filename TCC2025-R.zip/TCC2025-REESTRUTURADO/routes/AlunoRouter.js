const express = require('express');
const autenticarAluno = require('../middleware/autenticarAluno.js');
const Aluno = require('../models/Aluno');

const router = express.Router();


router.post('/login', async (req, res) => {
    const { emailAluno, senhaAluno } = req.body;

    if (!emailAluno || !senhaAluno) {
        return res.status(400).json({ erro: 'Email e senha são obrigatórios' });
    }

    const aluno = new Aluno();
    aluno.emailAluno = emailAluno;
    aluno.senhaAluno = senhaAluno;

    try {
        const sucesso = await aluno.login();
        if (sucesso) {

            req.session.alunoLogado = {
                email: aluno.emailAluno,
                nome: aluno.nomeAluno
            };

            return res.status(200).json({ mensagem: 'Login realizado com sucesso' });
            
        } else {
            return res.status(401).json({ erro: 'Credenciais inválidas' });
        }
    } catch (erro) {
        console.error('Erro ao fazer login:', erro);
        res.status(500).json({ erro: 'Erro interno ao realizar login' });
    }
});

router.use(autenticarAluno);


router.delete('/:emailAluno', async (req, res) => {
    const { emailAluno } = req.params;

    const aluno = new Aluno();
    aluno.emailAluno = emailAluno;

    try {
        const excluido = await aluno.delete();
        if (excluido) {
            return res.json({ mensagem: 'Aluno excluído com sucesso' });
        } else {
            return res.status(404).json({ erro: 'Aluno não encontrado' });
        }
    } catch (erro) {
        console.error('Erro ao excluir aluno:', erro);
        res.status(500).json({ erro: 'Erro ao excluir aluno' });
    }
});

router.get('/', async (req, res) => {
    try {
        const aluno = new Aluno();
        const lista = await aluno.readAll();
        res.json(lista);
    } catch (erro) {
        console.error('Erro ao listar alunos:', erro);
        res.status(500).json({ erro: 'Erro ao listar alunos' });
    }
});


router.post('/', async (req, res) => {
    const { nomeAluno, emailAluno, senhaAluno, turma, idCurso } = req.body;

    if (!nomeAluno || !emailAluno || !senhaAluno) {
        return res.status(400).json({ erro: 'Campos obrigatórios não preenchidos' });
    }

    const aluno = new Aluno();
    aluno.nomeAluno = nomeAluno;
    aluno.emailAluno = emailAluno;
    aluno.senhaAluno = senhaAluno;
    aluno.turma = turma;
    aluno.idCurso = idCurso;

    try {
        const criado = await aluno.create();
        if (criado) {
            return res.status(201).json({ mensagem: 'Aluno criado com sucesso!' });
        } else {
            return res.status(500).json({ erro: 'Erro ao criar aluno' });
        }
    } catch (erro) {
        console.error('Erro ao criar aluno:', erro);
        res.status(500).json({ erro: 'Erro ao criar aluno' });
    }
});


module.exports = router;
