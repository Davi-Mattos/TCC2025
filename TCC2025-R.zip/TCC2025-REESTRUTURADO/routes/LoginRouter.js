const express = require('express');
const Professor = require('../models/Professor');
const Aluno = require('../models/Aluno');
const router = express.Router();

router.post('/', async (req, res) => {
  const { email, senha, tipo } = req.body;

  try {
    if (tipo === 'professor') {
      const professor = new Professor();
      professor.emailProfessor = email;
      professor.senhaProfessor = senha;
      
      if (await professor.login()) {
        req.session.usuario = {
          tipo: 'professor',
          email: professor.emailProfessor
        };
        return res.json({ success: true });
      }
    } else if (tipo === 'aluno') {
      const aluno = new Aluno();
      aluno.emailAluno = email;
      aluno.senhaAluno = senha;
      
      if (await aluno.login()) {
        req.session.usuario = {
          tipo: 'aluno',
          email: aluno.emailAluno
        };
        return res.json({ success: true });
      }
    }
    
    res.status(401).json({ error: 'Credenciais inválidas' });
  } catch (error) {
    console.error('Erro no login:', error);
    res.status(500).json({ error: 'Erro interno no servidor' });
  }
});

module.exports = router;