const express = require('express');
const autenticarCoordenador = require('../middleware/autenticarCoordenador');
const Coordenador = require('../models/Coordenador');

const router = express.Router();

// POST - Login (rota pública)
router.post('/login', async (req, res) => {
    const { emailCoordenador, senhaCoordenador } = req.body;

    if (!emailCoordenador || !senhaCoordenador) {
        return res.status(400).json({ erro: 'Email e senha são obrigatórios' });
    }

    const coordenador = new Coordenador();
    coordenador.emailCoordenador = emailCoordenador;
    coordenador.senhaCoordenador = senhaCoordenador;

    try {
        const sucesso = await coordenador.login();
        if (sucesso) {
            req.session.coordenadorLogado = {
                email: coordenador.emailCoordenador,
                nome: coordenador.nomeCoordenador
            };

            return res.status(200).json({ mensagem: 'Login realizado com sucesso' });
        } else {
            return res.status(401).json({ erro: 'Credenciais inválidas' });
        }
    } catch (erro) {
        console.error('Erro ao fazer login:', erro);
        res.status(500).json({ erro: 'Erro interno ao realizar login' });
    }
});

// Middleware de autenticação aplicado a partir daqui
router.use(autenticarCoordenador);

// GET - Listar todos os coordenadores
router.get('/', async (req, res) => {
    try {
        const coordenador = new Coordenador();
        const lista = await coordenador.readAll();
        res.json(lista);
    } catch (erro) {
        console.error('Erro ao listar coordenadores:', erro);
        res.status(500).json({ erro: 'Erro ao listar coordenadores' });
    }
});

// POST - Criar novo coordenador
router.post('/', async (req, res) => {
    const { nomeCoordenador, emailCoordenador, senhaCoordenador } = req.body;

    if (!nomeCoordenador || !emailCoordenador || !senhaCoordenador) {
        return res.status(400).json({ erro: 'Campos obrigatórios não preenchidos' });
    }

    const coordenador = new Coordenador();
    coordenador.nomeCoordenador = nomeCoordenador;
    coordenador.emailCoordenador = emailCoordenador;
    coordenador.senhaCoordenador = senhaCoordenador;

    try {
        const criado = await coordenador.create();
        if (criado) {
            return res.status(201).json({ mensagem: 'Coordenador criado com sucesso!' });
        } else {
            return res.status(500).json({ erro: 'Erro ao criar coordenador' });
        }
    } catch (erro) {
        console.error('Erro ao criar coordenador:', erro);
        res.status(500).json({ erro: 'Erro ao criar coordenador' });
    }
});

// DELETE - Excluir coordenador
router.delete('/:emailCoordenador', async (req, res) => {
    const { emailCoordenador } = req.params;

    const coordenador = new Coordenador();
    coordenador.emailCoordenador = emailCoordenador;

    try {
        const excluido = await coordenador.delete();
        if (excluido) {
            return res.json({ mensagem: 'Coordenador excluído com sucesso' });
        } else {
            return res.status(404).json({ erro: 'Coordenador não encontrado' });
        }
    } catch (erro) {
        console.error('Erro ao excluir coordenador:', erro);
        res.status(500).json({ erro: 'Erro ao excluir coordenador' });
    }
});

module.exports = router;
