const session = require('express-session');
const express = require('express');

const router = express.Router();

router.use(session({
    secret: 'dois-pes-de-trigo',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false } // true se usar HTTPS
}));
