const express = require('express');
const path = require('path');
const router = express.Router();

router.get('/login', (req, res) => res.sendFile(path.join(__dirname, './../views/login.html')));
router.get('/alunos', (req, res) => res.sendFile(path.join(__dirname, './../views/alunos.html')));
router.get('/professores', (req, res) => res.sendFile(path.join(__dirname, './../views/professores.html')));
router.get('/entrega', (req, res) => res.sendFile(path.join(__dirname, './../views/entrega.html')));
router.get('/cadastrargrupo', (req, res) => res.sendFile(path.join(__dirname, './../views/cadastrargrupo.html')));
router.get('/', (req, res) => res.sendFile(path.join(__dirname, './../views/inicial.html')));

module.exports = router;
