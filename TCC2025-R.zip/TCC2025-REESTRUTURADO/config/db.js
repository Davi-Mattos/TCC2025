// config/db.js
const mysql = require('mysql2');

const pool = mysql.createPool({
    host: 'localhost',
    user: 'seu_usuario',
    password: 'sua_senha',
    database: 'tcc2025',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

const getConexao = () => pool;

module.exports = {
    getConexao
};