function autenticarProfessor(req, res, next) {
    if (req.session && req.session.professorLogado) {
        next();
    } else {
        res.status(401).json({ erro: 'Você precisa estar logado como professor.' });
    }
}

module.exports = autenticarProfessor;
