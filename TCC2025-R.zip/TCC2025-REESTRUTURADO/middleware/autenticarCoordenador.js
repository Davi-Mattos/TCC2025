function autenticarCoordenador(req, res, next) {
    if (req.session && req.session.coordenadorLogado) {
        next();
    } else {
        res.status(401).json({ erro: 'Você precisa estar logado como coordenador.' });
    }
}

module.exports = autenticarCoordenador;
