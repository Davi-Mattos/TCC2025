const express = require('express');
const Aluno = require('../models/Aluno');
const jwtClass = require('../models/MeuTokenJWT'); 

module.exports = class AlunoControl {

    async login(request, response) {
        const aluno = new Aluno();

        aluno.emailAluno = request.body.aluno.email;
        aluno.senha = request.body.aluno.senha;

        const logou = await aluno.login();

        if (logou === true) {
            const objResposta = {
                cod: 1,
                status: true,
                msg: 'Logado com sucesso',
                aluno: {
                    email: aluno.emailAluno
                }
            };
            response.status(200).send(objResposta);
        } else {
            const objResposta = {
                cod: 2,
                status: false,
                msg: "Erro ao efetuar login"
            };
            response.status(401).send(objResposta);
        }
    }

    async readAll(request, response) {
        const aluno = new Aluno();
        const dadosAlunoes = await aluno.readAll();

        const objResposta = {
            cod: 1,
            status: true,
            alunoes: dadosAlunoes
        };
        response.status(200).send(objResposta);
    }

    async readById(request, response) {
        const aluno = new Aluno();
        aluno.emailAluno = request.params.email;

        const dados = await aluno.readByID();

        const objResposta = {
            cod: 1,
            status: true,
            alunoes: dados
        };
        response.status(200).send(objResposta);
    }

    async create(request, response) {
        const aluno = new Aluno();
        aluno.nomeAluno = request.body.aluno.nome;
        aluno.emailAluno = request.body.aluno.email;
        aluno.senha = request.body.aluno.senha;

        const sucesso = await aluno.create();

        if (sucesso === true) {
            const objResposta = {
                cod: 1,
                status: true,
                alunoes: [{
                    email: aluno.emailAluno
                }]
            };
            response.status(201).send(objResposta);
        } else {
            const objResposta = {
                cod: 1,
                status: false,
                msg: "Falha ao cadastrar aluno",
                alunoes: [{
                    email: aluno.emailAluno
                }]
            };
            response.status(200).send(objResposta);
        }
    }

    async update(request, response) {
        const aluno = new Aluno();
        aluno.emailAluno = request.params.email;
        aluno.senha = request.body.aluno.senha;

        const atualizou = await aluno.update();

        const objResposta = {
            cod: 1,
            status: atualizou,
            msg: atualizou ? "Atualizado com sucesso" : "Falha ao atualizar aluno",
            alunoes: [{
                email: aluno.emailAluno
            }]
        };
        response.status(200).send(objResposta);
    }

    async delete(request, response) {
        const aluno = new Aluno();
        aluno.emailAluno = request.params.email;

        const excluiu = await aluno.delete();

        const objResposta = {
            cod: 1,
            status: excluiu,
            msg: excluiu ? "Excluído com sucesso" : "Falha ao excluir aluno",
            alunoes: [{
                email: aluno.emailAluno
            }]
        };
        response.status(200).send(objResposta);
    }
};
