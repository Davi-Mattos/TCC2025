const bcrypt = require('bcrypt');
const Banco = require('../config/db');

class Professor {
    constructor() {
        this._idProfessor = null;
        this._nomeProfessor = null;
        this._emailProfessor = null;
        this._senhaProfessor = null;
    }

    async create() {
        const conexao = Banco.getConexao();
        const saltRounds = 10;

        try {
            const senhaHash = await bcrypt.hash(this._senhaProfessor, saltRounds);
            const SQL = `
                INSERT INTO professor 
                (nomeProfessor, emailProfessor, senhaProfessor) 
                VALUES (?, ?, ?);
            `;

            const [result] = await conexao.promise().execute(SQL, [
                this._nomeProfessor,
                this._emailProfessor,
                senhaHash
            ]);

            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro ao criar Professor:', error);
            return false;
        }
    }

    async update() {
        const conexao = Banco.getConexao();
        const saltRounds = 10;

        try {
            const senhaHash = await bcrypt.hash(this._senhaProfessor, saltRounds);
            const SQL = 'UPDATE professor SET senhaProfessor = ? WHERE emailProfessor = ?;';
            const [result] = await conexao.promise().execute(SQL, [senhaHash, this._emailProfessor]);

            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro ao atualizar o Professor:', error);
            return false;
        }
    }

    async login() {
        const conexao = Banco.getConexao();
        const SQL = `
            SELECT senhaProfessor, emailProfessor
            FROM professor 
            WHERE emailProfessor = ?;
        `;

        try {
            const [rows] = await conexao.promise().execute(SQL, [this._emailProfessor]);

            if (rows.length === 1) {
                const hashArmazenado = rows[0].senhaProfessor;
                const senhaCorreta = await bcrypt.compare(this._senhaProfessor, hashArmazenado);

                if (senhaCorreta) {
                    this._emailProfessor = rows[0].emailProfessor;
                    return true;
                }
            }

            return false;
        } catch (error) {
            console.error('Erro ao realizar o login do Professor:', error);
            return false;
        }
    }

    async delete() {
        const conexao = Banco.getConexao();
        const SQL = 'DELETE FROM professor WHERE emailProfessor = ?;';
        try {
            const [result] = await conexao.promise().execute(SQL, [this._emailProfessor]);
            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro ao excluir o Professor:', error);
            return false;
        }
    }

    async readAll() {
        const conexao = Banco.getConexao();
        const SQL = 'SELECT * FROM professor ORDER BY emailProfessor;';
        try {
            const [rows] = await conexao.promise().execute(SQL);
            return rows;
        } catch (error) {
            console.error('Erro ao ler Professores:', error);
            return [];
        }
    }

    async readByEmail() {
        const conexao = Banco.getConexao();
        const SQL = 'SELECT * FROM professor WHERE emailProfessor = ?;';
        try {
            const [rows] = await conexao.promise().execute(SQL, [this._emailProfessor]);
            return rows;
        } catch (error) {
            console.error('Erro ao ler Professor pelo email:', error);
            return null;
        }
    }

    async isUsuarioByEmail(email) {
        const conexao = Banco.getConexao();
        const SQL = 'SELECT COUNT(*) AS qtd FROM professor WHERE emailProfessor = ?;';
        try {
            const [rows] = await conexao.promise().execute(SQL, [email]);
            return rows[0].qtd > 0;
        } catch (error) {
            console.error('Erro ao verificar o email do Professor:', error);
            return false;
        }
    }

   

    get idProfessor() { return this._idProfessor; }
    set idProfessor(id) { this._idProfessor = id; }

    get nomeProfessor() { return this._nomeProfessor; }
    set nomeProfessor(nome) { this._nomeProfessor = nome; }

    get emailProfessor() { return this._emailProfessor; }
    set emailProfessor(email) { this._emailProfessor = email; }

    get senhaProfessor() { return this._senhaProfessor; }
    set senhaProfessor(senha) { this._senhaProfessor = senha; }
}

module.exports = Professor;
