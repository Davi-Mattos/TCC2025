const bcrypt = require('bcrypt');
const Banco = require('../config/db');

class Coordenador {
    constructor() {
        this._idCoordenador = null;
        this._nomeCoordenador = null;
        this._emailCoordenador = null;
        this._senhaCoordenador = null;
    }

    async create() {
        const conexao = Banco.getConexao();
        const saltRounds = 10;

        try {
            const senhaHash = await bcrypt.hash(this._senhaCoordenador, saltRounds);
            const SQL = `
                INSERT INTO coordenador 
                (nomeCoordenador, emailCoordenador, senhaCoordenador) 
                VALUES (?, ?, ?);
            `;

            const [result] = await conexao.promise().execute(SQL, [
                this._nomeCoordenador,
                this._emailCoordenador,
                senhaHash
            ]);

            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro ao criar Coordenador:', error);
            return false;
        }
    }

    async update() {
        const conexao = Banco.getConexao();
        const saltRounds = 10;

        try {
            const senhaHash = await bcrypt.hash(this._senhaCoordenador, saltRounds);
            const SQL = 'UPDATE coordenador SET senhaCoordenador = ? WHERE emailCoordenador = ?;';
            const [result] = await conexao.promise().execute(SQL, [senhaHash, this._emailCoordenador]);

            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro ao atualizar o Coordenador:', error);
            return false;
        }
    }

    async login() {
        const conexao = Banco.getConexao();
        const SQL = `
            SELECT senhaCoordenador, emailCoordenador
            FROM coordenador 
            WHERE emailCoordenador = ?;
        `;

        try {
            const [rows] = await conexao.promise().execute(SQL, [this._emailCoordenador]);

            if (rows.length === 1) {
                const hashArmazenado = rows[0].senhaCoordenador;
                const senhaCorreta = await bcrypt.compare(this._senhaCoordenador, hashArmazenado);

                if (senhaCorreta) {
                    this._emailCoordenador = rows[0].emailCoordenador;
                    return true;
                }
            }

            return false;
        } catch (error) {
            console.error('Erro ao realizar o login do Coordenador:', error);
            return false;
        }
    }

    async delete() {
        const conexao = Banco.getConexao();
        const SQL = 'DELETE FROM coordenador WHERE emailCoordenador = ?;';
        try {
            const [result] = await conexao.promise().execute(SQL, [this._emailCoordenador]);
            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro ao excluir o Coordenador:', error);
            return false;
        }
    }

    async readAll() {
        const conexao = Banco.getConexao();
        const SQL = 'SELECT * FROM coordenador ORDER BY emailCoordenador;';
        try {
            const [rows] = await conexao.promise().execute(SQL);
            return rows;
        } catch (error) {
            console.error('Erro ao ler Coordenadores:', error);
            return [];
        }
    }

    async readByEmail() {
        const conexao = Banco.getConexao();
        const SQL = 'SELECT * FROM coordenador WHERE emailCoordenador = ?;';
        try {
            const [rows] = await conexao.promise().execute(SQL, [this._emailCoordenador]);
            return rows;
        } catch (error) {
            console.error('Erro ao ler Coordenador pelo email:', error);
            return null;
        }
    }

    async isUsuarioByEmail(email) {
        const conexao = Banco.getConexao();
        const SQL = 'SELECT COUNT(*) AS qtd FROM coordenador WHERE emailCoordenador = ?;';
        try {
            const [rows] = await conexao.promise().execute(SQL, [email]);
            return rows[0].qtd > 0;
        } catch (error) {
            console.error('Erro ao verificar o email do Coordenador:', error);
            return false;
        }
    }

    // Getters e Setters
    get idCoordenador() { return this._idCoordenador; }
    set idCoordenador(id) { this._idCoordenador = id; }

    get nomeCoordenador() { return this._nomeCoordenador; }
    set nomeCoordenador(nome) { this._nomeCoordenador = nome; }

    get emailCoordenador() { return this._emailCoordenador; }
    set emailCoordenador(email) { this._emailCoordenador = email; }

    get senhaCoordenador() { return this._senhaCoordenador; }
    set senhaCoordenador(senha) { this._senhaCoordenador = senha; }
}

module.exports = Coordenador;
